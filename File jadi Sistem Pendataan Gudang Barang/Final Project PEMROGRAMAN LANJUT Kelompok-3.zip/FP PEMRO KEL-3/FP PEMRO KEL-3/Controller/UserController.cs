﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    // Kelas UserController bertanggung jawab untuk menangani operasi CRUD pada data User
    public class UserController
    {
        // Simulasi penyimpanan database dengan List<User>
        private List<User> users = new List<User>();

        // Create: Menambahkan user baru ke dalam List
        public void TambahUser(User user)
        {
            // Validasi jika user yang ditambahkan adalah null
            if (user == null)
                throw new ArgumentNullException(nameof(user), "User tidak boleh null.");

            // Menentukan ID baru untuk user (mengambil ID terbesar yang ada, kemudian ditambah 1)
            user.IdPengguna = users.Count > 0 ? users.Max(u => u.IdPengguna) + 1 : 1; // Generate ID
            users.Add(user);  // Menambahkan user ke dalam List
            Console.WriteLine("User berhasil ditambahkan.");  // Menampilkan pesan berhasil
        }

        // Read: Mendapatkan semua user dari List
        public List<User> ReadAllUser()
        {
            return users;  // Mengembalikan seluruh data user yang ada
        }

        // Read: Mencari user berdasarkan ID
        public User CariUserBerdasarkanId(int id)
        {
            // Mencari user berdasarkan ID menggunakan metode Find
            var user = users.Find(u => u.IdPengguna == id);

            // Jika user tidak ditemukan, tampilkan pesan dan kembalikan null
            if (user == null)
            {
                Console.WriteLine($"User dengan ID {id} tidak ditemukan.");
                return null;
            }

            return user;  // Mengembalikan user yang ditemukan
        }

        // Update: Memperbarui data user berdasarkan ID
        public void PerbaruiUser(int id, User userBaru)
        {
            // Mencari user yang ingin diperbarui berdasarkan ID
            var user = CariUserBerdasarkanId(id);

            // Jika user tidak ditemukan, tampilkan pesan dan batalkan pembaruan
            if (user == null)
            {
                Console.WriteLine("User tidak ditemukan.");
                return;
            }

            // Memperbarui data user dengan informasi baru dari userBaru
            user.NamaPengguna = userBaru.NamaPengguna;
            user.Username = userBaru.Username;
            user.Sandi = userBaru.Sandi;
            user.Role = userBaru.Role;

            Console.WriteLine("User berhasil diperbarui.");  // Menampilkan pesan bahwa pembaruan berhasil
        }

        // Delete: Menghapus user berdasarkan ID
        public void HapusUser(int id)
        {
            // Mencari user yang ingin dihapus berdasarkan ID
            var user = CariUserBerdasarkanId(id);

            // Jika user tidak ditemukan, tampilkan pesan dan batalkan penghapusan
            if (user == null)
            {
                Console.WriteLine("User tidak ditemukan.");
                return;
            }

            // Menghapus user dari List
            users.Remove(user);
            Console.WriteLine("User berhasil dihapus.");  // Menampilkan pesan bahwa user telah dihapus
        }
    }
}
