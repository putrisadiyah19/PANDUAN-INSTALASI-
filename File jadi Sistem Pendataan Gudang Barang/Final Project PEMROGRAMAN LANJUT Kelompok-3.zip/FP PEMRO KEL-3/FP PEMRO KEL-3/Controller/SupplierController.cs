﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    // Controller untuk menangani operasi CRUD pada entitas Supplier
    public class SupplierController
    {
        // Variabel untuk repository yang menangani operasi database
        private SupplierRepository _repository;

        // List untuk menyimpan data supplier (simulasi penyimpanan data)
        private List<Supplier> suppliers = new List<Supplier>();

        // Create: Menambahkan supplier baru
        public void CreateSupplier(Supplier supplier)
        {
            // Validasi: Memastikan supplier tidak null
            if (supplier == null)
                throw new ArgumentNullException(nameof(supplier));

            // Menambahkan supplier ke dalam list
            suppliers.Add(supplier);

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Supplier berhasil ditambahkan!");
        }

        // Read: Menampilkan semua supplier
        public List<Supplier> ReadAllSupplier()
        {
            // Mengembalikan seluruh daftar supplier
            return suppliers;
        }

        // Read: Mencari supplier berdasarkan ID
        public Supplier CariSupplierBerdasarkanId(int id)
        {
            // Mencari supplier berdasarkan ID dengan menggunakan LINQ
            return suppliers.Find(s => s.IdSupplier == id);
        }

        // Update: Memperbarui supplier yang sudah ada
        public void UpdateSupplier(int id, Supplier supplierBaru)
        {
            // Mencari supplier berdasarkan ID
            var supplier = CariSupplierBerdasarkanId(id);

            // Jika supplier tidak ditemukan, tampilkan pesan dan keluar dari method
            if (supplier == null)
            {
                Console.WriteLine("Supplier tidak ditemukan!");
                return;
            }

            // Memperbarui informasi supplier
            supplier.NamaSupplier = supplierBaru.NamaSupplier;
            supplier.Alamat = supplierBaru.Alamat;
            supplier.Email = supplierBaru.Email;
            supplier.Kontak = supplierBaru.Kontak;

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Supplier berhasil diperbarui!");
        }

        // Delete: Menghapus supplier berdasarkan ID
        public void DeletSupplier(int id)
        {
            // Mencari supplier berdasarkan ID
            var supplier = CariSupplierBerdasarkanId(id);

            // Jika supplier tidak ditemukan, tampilkan pesan dan keluar dari method
            if (supplier == null)
            {
                Console.WriteLine("Supplier tidak ditemukan!");
                return;
            }

            // Menghapus supplier dari list
            suppliers.Remove(supplier);

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Supplier berhasil dihapus!");
        }
    }
}
