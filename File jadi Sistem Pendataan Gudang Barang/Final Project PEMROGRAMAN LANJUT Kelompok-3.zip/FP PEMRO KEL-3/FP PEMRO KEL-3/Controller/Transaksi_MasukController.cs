﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    // Controller untuk menangani operasi CRUD pada entitas Transaksi_Masuk
    internal class Transaksi_MasukController
    {
        // Variabel untuk repository yang menangani operasi database
        private Transaksi_MasukRepo _repository;

        // Konstruktor yang menerima DbContext dan menginisialisasi repository
        public Transaksi_MasukController(DbContext context)
        {
            // Membuat instance dari repository dan memberikan context ke repository
            _repository = new Transaksi_MasukRepo(context);
        }

        // Method untuk menambah transaksi baru ke dalam database
        public int Create(Transaksi_Masuk transaksi)
        {
            // Validasi untuk memastikan transaksi tidak null
            if (transaksi == null)
                throw new ArgumentNullException("Data transaksi tidak boleh null");

            // Memanggil method Create dari repository untuk menyimpan data transaksi
            return _repository.Create(transaksi);
        }

        // Method untuk mengambil semua data transaksi masuk dari database
        public List<Transaksi_Masuk> ReadAll()
        {
            // Memanggil method ReadAll dari repository untuk mendapatkan daftar transaksi
            return _repository.ReadAll();
        }

        // Method untuk memperbarui data transaksi yang ada
        public int Update(Transaksi_Masuk transaksi)
        {
            // Validasi untuk memastikan transaksi tidak null
            if (transaksi == null)
                throw new ArgumentNullException("Data transaksi tidak boleh null");

            // Memanggil method Update dari repository untuk memperbarui transaksi
            return _repository.Update(transaksi);
        }

        // Method untuk menghapus transaksi berdasarkan ID
        public int Delete(int idTransaksi)
        {
            // Validasi untuk memastikan ID transaksi valid (lebih besar dari 0)
            if (idTransaksi <= 0)
                throw new ArgumentException("ID transaksi harus valid");

            // Memanggil method Delete dari repository untuk menghapus transaksi
            return _repository.Delete(idTransaksi);
        }
    }
}
