﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    // Controller untuk menangani operasi CRUD pada entitas Kategori_Barang
    public class Kategori_BarangController
    {
        // Variabel untuk repository yang menangani operasi database
        private Kategori_BarangRepository _repository;

        // List untuk menyimpan data kategori barang (simulasi penyimpanan data)
        private List<Kategori_Barang> kategoriBarangs = new List<Kategori_Barang>();

        // Create: Menambahkan kategori barang baru
        public void TambahKategori(Kategori_Barang kategori)
        {
            // Validasi: Memastikan kategori tidak null
            if (kategori == null)
                throw new ArgumentNullException(nameof(kategori));

            // Menambahkan kategori ke dalam list
            kategoriBarangs.Add(kategori);

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Kategori berhasil ditambahkan!");
        }

        // Read: Menampilkan semua kategori barang
        public List<Kategori_Barang> TampilkanSemuaKategori()
        {
            // Mengembalikan seluruh daftar kategori barang
            return kategoriBarangs;
        }

        // Read: Mencari kategori barang berdasarkan ID
        public Kategori_Barang CariKategoriBerdasarkanId(int id)
        {
            // Mencari kategori berdasarkan ID dengan menggunakan LINQ
            return kategoriBarangs.Find(k => k.IdKategori == id);
        }

        // Update: Memperbarui kategori barang yang sudah ada
        public void PerbaruiKategori(int id, Kategori_Barang kategoriBaru)
        {
            // Mencari kategori berdasarkan ID
            var kategori = CariKategoriBerdasarkanId(id);

            // Jika kategori tidak ditemukan, tampilkan pesan dan keluar dari method
            if (kategori == null)
            {
                Console.WriteLine("Kategori tidak ditemukan!");
                return;
            }

            // Memperbarui informasi kategori
            kategori.NamaKategori = kategoriBaru.NamaKategori;
            kategori.Deskripsi = kategoriBaru.Deskripsi;

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Kategori berhasil diperbarui!");
        }

        // Delete: Menghapus kategori barang berdasarkan ID
        public void HapusKategori(int id)
        {
            // Mencari kategori berdasarkan ID
            var kategori = CariKategoriBerdasarkanId(id);

            // Jika kategori tidak ditemukan, tampilkan pesan dan keluar dari method
            if (kategori == null)
            {
                Console.WriteLine("Kategori tidak ditemukan!");
                return;
            }

            // Menghapus kategori dari list
            kategoriBarangs.Remove(kategori);

            // Menampilkan pesan keberhasilan di console
            Console.WriteLine("Kategori berhasil dihapus!");
        }

    }
}
