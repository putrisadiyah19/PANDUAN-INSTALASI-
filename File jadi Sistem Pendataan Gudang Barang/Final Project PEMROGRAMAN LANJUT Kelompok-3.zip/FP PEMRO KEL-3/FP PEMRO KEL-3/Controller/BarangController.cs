﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    // Controller untuk menangani operasi CRUD pada entitas Barang
    internal class BarangController
    {
        // Variabel untuk repository yang menangani operasi database
        private BarangRepository _repository;

        // Konstruktor yang menerima DbContext dan menginisialisasi repository
        public BarangController(DbContext context)
        {
            // Membuat instance dari repository dan memberikan context ke repository
            _repository = new BarangRepository(context);
        }

        // Method untuk menambah barang baru ke dalam database
        public int Create(Barang barang)
        {
            // Validasi untuk memastikan barang tidak null
            if (barang == null)
                throw new ArgumentNullException("Barang tidak boleh null");

            // Validasi untuk memastikan nama barang tidak kosong
            if (string.IsNullOrEmpty(barang.NamaBarang))
                throw new ArgumentException("Nama barang tidak boleh kosong");

            // Memanggil method Create dari repository untuk menyimpan data barang
            return _repository.Create(barang);
        }

        // Method untuk memperbarui data barang yang ada
        public int Update(Barang barang)
        {
            // Validasi untuk memastikan barang tidak null
            if (barang == null)
                throw new ArgumentNullException("Barang tidak boleh null");

            // Validasi untuk memastikan IdBarang valid (lebih besar dari 0)
            if (barang.IdBarang <= 0)
                throw new ArgumentException("Id barang tidak valid");

            // Memanggil method Update dari repository untuk memperbarui barang
            return _repository.Update(barang);
        }

        // Method untuk menghapus barang berdasarkan objek barang yang diberikan
        public int Delete(Barang barang)
        {
            // Validasi untuk memastikan barang tidak null
            if (barang == null)
                throw new ArgumentNullException("Barang tidak boleh null");

            // Validasi untuk memastikan IdBarang valid (lebih besar dari 0)
            if (barang.IdBarang <= 0)
                throw new ArgumentException("Id barang tidak valid");

            // Memanggil method Delete dari repository untuk menghapus barang
            return _repository.Delete(barang);
        }

        // Method untuk mencari barang berdasarkan nama barang
        public List<Barang> ReadByNama(string namaBarang)
        {
            // Validasi untuk memastikan nama barang tidak kosong
            if (string.IsNullOrEmpty(namaBarang))
                throw new ArgumentException("Nama barang tidak boleh kosong");

            // Memanggil method ReadByNama dari repository untuk mencari barang berdasarkan nama
            return _repository.ReadByNama(namaBarang);
        }
    }
}