﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Controller
{
    public class Transaksi_KeluarController
    {
        private readonly Transaksi_KeluarRepo _repository;

        // Konstruktor yang menerima Transaksi_KeluarRepo sebagai parameter melalui Dependency Injection
        internal Transaksi_KeluarController(Transaksi_KeluarRepo repository)
        {
            // Mengecek apakah repository null dan melemparkan ArgumentNullException jika ya
            _repository = repository ?? throw new ArgumentNullException(nameof(repository), "Repository cannot be null");
        }

        // Method untuk membuat transaksi baru
        public bool Create(Transaksi_Keluar transaksi)
        {
            // Mengecek apakah parameter transaksi null
            if (transaksi == null)
            {
                throw new ArgumentNullException(nameof(transaksi), "Data transaksi tidak boleh null");
            }

            try
            {
                // Memanggil metode Create pada repository dan memeriksa apakah berhasil (lebih dari 0 berarti berhasil)
                return _repository.Create(transaksi) > 0;
            }
            catch (Exception ex)
            {
                // Jika terjadi kesalahan, kita membungkus pengecualian asli ke dalam InvalidOperationException
                // dan menambahkan pesan error yang lebih deskriptif
                // Di sini bisa ditambahkan logging (misalnya ke file log atau sistem monitoring)
                throw new InvalidOperationException("An error occurred while creating transaksi", ex);
            }
        }

        // Method untuk membaca semua transaksi
        public List<Transaksi_Keluar> ReadAll()
        {
            try
            {
                // Mengambil data semua transaksi dari repository
                return _repository.ReadAll();
            }
            catch (Exception ex)
            {
                // Jika terjadi kesalahan, kita membungkus pengecualian dan memberikan pesan error
                throw new InvalidOperationException("An error occurred while reading transaksi", ex);
            }
        }

        // Method untuk memperbarui data transaksi
        public bool Update(Transaksi_Keluar transaksi)
        {
            // Mengecek apakah parameter transaksi null
            if (transaksi == null)
            {
                throw new ArgumentNullException(nameof(transaksi), "Data transaksi tidak boleh null");
            }

            try
            {
                // Memanggil metode Update pada repository dan memeriksa apakah berhasil (lebih dari 0 berarti berhasil)
                return _repository.Update(transaksi) > 0;
            }
            catch (Exception ex)
            {
                // Jika terjadi kesalahan, kita membungkus pengecualian asli ke dalam InvalidOperationException
                throw new InvalidOperationException("An error occurred while updating transaksi", ex);
            }
        }

        // Method untuk menghapus transaksi berdasarkan ID
        public bool Delete(int idTransaksi)
        {
            // Mengecek apakah ID transaksi valid (harus lebih dari 0)
            if (idTransaksi <= 0)
            {
                throw new ArgumentException("ID transaksi harus valid", nameof(idTransaksi));
            }

            try
            {
                // Memanggil metode Delete pada repository dan memeriksa apakah berhasil (lebih dari 0 berarti berhasil)
                return _repository.Delete(idTransaksi) > 0;
            }
            catch (Exception ex)
            {
                // Jika terjadi kesalahan, kita membungkus pengecualian asli ke dalam InvalidOperationException
                throw new InvalidOperationException("An error occurred while deleting transaksi", ex);
            }
        }
    }
}
