﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Entity
{
    public class Transaksi_Keluar
    {   
        public int IdTransaksiKeluar { get; set; }

        public int? IdBarang { get; set; }
        public Barang Barang { get; set; }

        public int? IdPengguna { get; set; }
        public User Pengguna { get; set; }

        public DateTime TanggalKeluar { get; set; }
        public int Jumlah { get; set; }
        public String Tujuan { get; set; }
    }
}
