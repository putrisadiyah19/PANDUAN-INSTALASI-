﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Entity
{
    public class Transaksi_Masuk
    {
        public int IdTransaksiMasuk { get; set; }

        public int? IdBarang { get; set; }
        public Barang Barang { get; set; }

        public int? IdSupplier { get; set; }
        public Supplier Supplier { get; set; }

        public int? IdPengguna {  get; set; }
        public User Pengguna { get; set; }

        public DateTime TanggalMasuk { get; set; }
        public int Jumlah {  get; set; }
        public decimal HargaTotal { get; set; }
    }
}
