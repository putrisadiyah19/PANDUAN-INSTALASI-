﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Entity
{
    public  class Barang
    {
        public int Stok {  get; set; }
        public int IdBarang { get; set; }
        public string NamaBarang { get; set; }
        public string Deskripsi { get; set; }
        public decimal HargaSatuan { get; set; }
        public int? IdKategori { get; set; }
        public Kategori_Barang Kategori { get; set; }


    }
}
