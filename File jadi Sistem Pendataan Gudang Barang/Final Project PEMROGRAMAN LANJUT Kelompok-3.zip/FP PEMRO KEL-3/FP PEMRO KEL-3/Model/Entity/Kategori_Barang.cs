﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Entity
{
    public class Kategori_Barang
    {
        public string Deskripsi{ get; set; }
        public string NamaKategori { get; set; }
        public int IdKategori { get; set; }
    }
}
