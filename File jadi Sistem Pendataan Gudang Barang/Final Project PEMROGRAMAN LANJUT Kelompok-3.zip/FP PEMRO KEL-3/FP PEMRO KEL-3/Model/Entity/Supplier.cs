﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Entity
{
    public class Supplier
    {  
        public int IdSupplier { get; set; }
        public string NamaSupplier { get; set; }
        public string Alamat { get; set; }
        public string Email { get; set; }
        public string Kontak { get; set; }
    }

}
