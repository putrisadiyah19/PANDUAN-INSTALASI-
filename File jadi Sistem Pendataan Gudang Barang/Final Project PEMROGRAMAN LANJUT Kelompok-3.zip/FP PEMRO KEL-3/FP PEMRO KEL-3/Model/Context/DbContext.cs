﻿using System;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace FP_PEMRO_KEL_3.Model.Context
{
    public class DbContext : IDisposable
    {
        // deklarasi private variabel / field
        private MySqlConnection _conn;

        // deklarasi property Conn (connection), untuk menyimpan objek koneksi
        public MySqlConnection Conn
        {
            get { return _conn ?? (_conn = GetOpenConnection()); }
        }

        // Method untuk melakukan koneksi ke database
        private MySqlConnection GetOpenConnection()
        {
            MySqlConnection conn = null; // deklarasi objek connection

            try // penggunaan blok try-catch untuk penanganan error
            {
                // atur ulang konfigurasi koneksi database yang disesuaikan dengan kebutuhan Anda
                string server = "localhost";
                string database = "gudang_barang";
                //string database = "gudang_barang";
                string user = "root";
                string password = "albedoimut123";

                // deklarasi variabel connectionString
                string connectionString = string.Format("Server={0};Database={1};User={2};Password={3};", server, database, user, password);

                conn = new MySqlConnection(connectionString); // buat objek connection
                conn.Open(); // buka koneksi ke database
            }
            // jika terjadi error di blok try, akan ditangani langsung oleh blok catch
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print("Open Connection Error: {0}", ex.Message);
            }

            return conn;
        }

        // Method ini digunakan untuk menghapus objek koneksi dari memory ketika sudah tidak digunakan
        public void Dispose()
        {
            if (_conn != null)
            {
                try
                {
                    if (_conn.State != ConnectionState.Closed) _conn.Close();
                }
                finally
                {
                    _conn.Dispose();
                }
            }

            GC.SuppressFinalize(this);
        }
    }
}
