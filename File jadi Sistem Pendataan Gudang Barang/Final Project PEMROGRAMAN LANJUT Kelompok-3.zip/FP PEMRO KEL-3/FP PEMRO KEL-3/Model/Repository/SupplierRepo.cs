﻿using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    public class SupplierRepository
    {
        // deklarasi objek connection
        private MySqlConnection _conn;

        // constructor
        public SupplierRepository(DbContext context)
        {
            // inisialisasi objek connection
            _conn = context.Conn;
        }

        public int Create(Supplier supplier)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"insert into tabel_supplier (id_supplier, nama_supplier, alamat, email, kontak) 
                         values (@id_supplier, @nama_supplier, @alamat, @email, @kontak)";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_supplier", supplier.IdSupplier);
                cmd.Parameters.AddWithValue("@nama_supplier", supplier.NamaSupplier);
                cmd.Parameters.AddWithValue("@alamat", supplier.Alamat);
                cmd.Parameters.AddWithValue("@email", supplier.Email);
                cmd.Parameters.AddWithValue("@kontak", supplier.Kontak);

                try
                {
                    // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            return result;
        }

        public int Update(Supplier supplier)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"update tabel_supplier set nama_supplier = @nama_supplier, alamat = @alamat, email = @email, kontak = @kontak 
                           where id_supplier = @id_supplier";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_supplier", supplier.IdSupplier);
                cmd.Parameters.AddWithValue("@nama_supplier", supplier.NamaSupplier);
                cmd.Parameters.AddWithValue("@alamat", supplier.Alamat);
                cmd.Parameters.AddWithValue("@email", supplier.Email);
                cmd.Parameters.AddWithValue("@kontak", supplier.Kontak);

                try
                {
                    // jalankan perintah UPDATE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result;
        }

        public int Delete(Supplier supplier)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"delete from tabel_supplier where id_supplier = @id_supplier";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_supllier", supplier.IdSupplier);

                try
                {
                    // jalankan perintah DELETE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result;
        }

        public List<Supplier> ReadAll()
        {
            // membuat objek collection untuk menampung objek supplier
            List<Supplier> list = new List<Supplier>();

            try
            {
                // deklarasi perintah SQL
                string sql = @"select id_supplier, nama_supplier, alamat, email, kontak 
                               from supplier order by nama_supplier";

                // membuat objek command menggunakan blok using
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // membuat objek dtr (data reader) untuk menampung result set
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // panggil method Read untuk mendapatkan baris dari result set
                        while (dtr.Read())
                        {
                            // proses konversi dari row result set ke object
                            Supplier supplier = new Supplier();
                            supplier.IdSupplier = Convert.ToInt32(dtr["id_supplier"]);
                            supplier.NamaSupplier = dtr["nama_supplier"].ToString();
                            supplier.Alamat = dtr["alamat"].ToString();
                            supplier.Email = dtr["stok"].ToString();
                            supplier.Kontak = dtr["kontak"].ToString();

                            // tambahkan objek supplier ke dalam collection
                            list.Add(supplier);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
            }

            return list;
        }

        public List<Supplier> ReadByNama(string namaSupplier)
        {
            // membuat objek collection untuk menampung objek supplier
            List<Supplier> list = new List<Supplier>();

            try
            {
                // deklarasi perintah SQL
                string sql = @"select id_supplier, nama_supplier, alamat, email, kontak 
                               from supplier where nama_supplier like @nama_supplier order by nama_supplier";

                // membuat objek command menggunakan blok using
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // mendaftarkan parameter dan mengeset nilainya
                    cmd.Parameters.AddWithValue("@nama_supplier", string.Format("%{0}%", namaSupplier));

                    // membuat objek dtr (data reader) untuk menampung result set
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // panggil method Read untuk mendapatkan baris dari result set
                        while (dtr.Read())
                        {
                            // proses konversi dari row result set ke object
                            Supplier supplier = new Supplier();
                            supplier.IdSupplier = Convert.ToInt32(dtr["id_supplier"]);
                            supplier.NamaSupplier = dtr["nama_supplier"].ToString();
                            supplier.Alamat = dtr["alamat"].ToString();
                            supplier.Email = dtr["stok"].ToString();
                            supplier.Kontak = dtr["kontak"].ToString();

                            // tambahkan objek supplier ke dalam collection
                            list.Add(supplier);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print("ReadByNama error: {0}", ex.Message);
            }

            return list;
        }
    }
}