﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    internal class Transaksi_MasukRepo
    {
        // Deklarasi objek koneksi ke database MySQL
        private MySqlConnection _conn;

        // Konstruktor untuk menginisialisasi koneksi dari DbContext
        public Transaksi_MasukRepo(DbContext context)
        {
            _conn = context.Conn;
        }

        // Method untuk menambahkan data transaksi masuk ke dalam database
        public int Create(Transaksi_Masuk transaksi)
        {
            int result = 0;

            // Query SQL untuk melakukan insert data transaksi masuk
            string sql = @"INSERT INTO tabel_transaksi_masuk (id_barang, id_pengguna, tanggal_masuk, jumlah, harga_total)
                            VALUES (@id_barang, @id_pengguna, @tanggal_masuk, @jumlah, @harga_total)";

            // Menggunakan blok 'using' untuk memastikan bahwa MySqlCommand dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter ke query dan mengisi nilainya untuk menghindari SQL Injection
                cmd.Parameters.AddWithValue("@id_barang", transaksi.IdBarang);
                cmd.Parameters.AddWithValue("@id_pengguna", transaksi.IdPengguna);
                cmd.Parameters.AddWithValue("@tanggal_masuk", transaksi.TanggalMasuk);
                cmd.Parameters.AddWithValue("@jumlah", transaksi.Jumlah);
                cmd.Parameters.AddWithValue("@harga_total", transaksi.HargaTotal);

                try
                {
                    // Menjalankan query untuk memasukkan data transaksi ke dalam database
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika ada masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            return result; // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
        }

        // Method untuk mengambil semua data transaksi masuk dari database
        public List<Transaksi_Masuk> ReadAll()
        {
            List<Transaksi_Masuk> list = new List<Transaksi_Masuk>();

            // Query SQL untuk mengambil semua transaksi masuk, diurutkan berdasarkan tanggal masuk
            string sql = @"SELECT id_transaksi_masuk, id_barang, id_pengguna, tanggal_masuk, jumlah, harga_total
                            FROM tabel_transaksi_masuk 
                            ORDER BY tanggal_masuk DESC;";

            // Menggunakan blok 'using' untuk memastikan MySqlCommand dan MySqlDataReader dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                try
                {
                    // Mengeksekusi query dan membaca hasilnya menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Membaca setiap baris hasil query dan mengonversinya ke objek Transaksi_Masuk
                        while (dtr.Read())
                        {
                            Transaksi_Masuk transaksi = new Transaksi_Masuk
                            {
                                IdTransaksiMasuk = Convert.ToInt32(dtr["id_transaksi_masuk"]),
                                IdBarang = Convert.ToInt32(dtr["id_barang"]),
                                IdPengguna = Convert.ToInt32(dtr["id_pengguna"]),
                                TanggalMasuk = Convert.ToDateTime(dtr["tanggal_masuk"]),
                                Jumlah = Convert.ToInt32(dtr["jumlah"]),
                                HargaTotal = Convert.ToInt32(dtr["harga_total"])
                            };
                            list.Add(transaksi); // Menambahkan objek transaksi ke dalam list
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Menangani error jika terjadi masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
                }
            }

            return list; // Mengembalikan list yang berisi semua transaksi masuk
        }

        // Method untuk memperbarui data transaksi masuk berdasarkan id_transaksi_masuk
        public int Update(Transaksi_Masuk transaksi)
        {
            int result = 0;

            // Query SQL untuk memperbarui data transaksi masuk
            string sql = @"UPDATE tabel_transaksi_masuk 
                           SET id_barang = @id_barang, id_pengguna = @id_pengguna, 
                           tanggal_masuk = @tanggal_masuk, jumlah = @jumlah 
                           WHERE id_transaksi_masuk = @id_transaksi_masuk";

            // Menggunakan blok 'using' untuk memastikan MySqlCommand dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter ke query dan mengisi nilainya untuk menghindari SQL Injection
                cmd.Parameters.AddWithValue("@id_barang", transaksi.IdBarang);
                cmd.Parameters.AddWithValue("@id_pengguna", transaksi.IdPengguna);
                cmd.Parameters.AddWithValue("@tanggal_masuk", transaksi.TanggalMasuk);
                cmd.Parameters.AddWithValue("@jumlah", transaksi.Jumlah);
                cmd.Parameters.AddWithValue("@id_transaksi_masuk", transaksi.IdTransaksiMasuk);
                cmd.Parameters.AddWithValue("@harga_total", transaksi.HargaTotal);

                try
                {
                    // Menjalankan query untuk memperbarui data transaksi masuk
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika ada masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result; // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
        }

        // Method untuk menghapus data transaksi masuk berdasarkan id_transaksi_masuk
        public int Delete(int idTransaksi)
        {
            int result = 0;

            // Query SQL untuk menghapus transaksi masuk berdasarkan id_transaksi_masuk
            string sql = @"DELETE FROM tabel_transaksi_masuk WHERE id_transaksi_masuk = @id_transaksi_masuk";

            // Menggunakan blok 'using' untuk memastikan MySqlCommand dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter ke query dan mengisi nilainya untuk menghindari SQL Injection
                cmd.Parameters.AddWithValue("@id_transaksi_masuk", idTransaksi);

                try
                {
                    // Menjalankan query untuk menghapus data transaksi masuk
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika ada masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result; // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
        }
    }
}