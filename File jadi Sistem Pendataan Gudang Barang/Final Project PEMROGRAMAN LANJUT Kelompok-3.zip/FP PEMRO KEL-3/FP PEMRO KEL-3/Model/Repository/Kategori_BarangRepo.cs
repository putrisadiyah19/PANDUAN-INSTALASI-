﻿using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    public class Kategori_BarangRepository
    {
        // deklarasi objek connection
        private MySqlConnection _conn;

        // constructor
        public Kategori_BarangRepository(DbContext context)
        {
            // inisialisasi objek connection
            _conn = context.Conn;
        }

        public int Create(Kategori_Barang kategoriBarang)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"insert into tabel_kategori_barang (id_kategori, nama_kategori, deskripsi) 
                         values (@id_kategori,@nama_kategori,@deskripsi)";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_kategori", kategoriBarang.IdKategori);
                cmd.Parameters.AddWithValue("@nama_kategori", kategoriBarang.NamaKategori);
                cmd.Parameters.AddWithValue("@deskripsi", kategoriBarang.Deskripsi);

                try
                {
                    // jalankan perintah INSERT dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            return result;
        }

        public int Update(Kategori_Barang kategoriBarang)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"update tabel_kategori_barang set nama_kategori = @nama_kategori, deskripsi = @deskripsi
                           where id_kategori = @id_kategori";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_kategori", kategoriBarang.IdKategori);
                cmd.Parameters.AddWithValue("@nama_kategori", kategoriBarang.NamaKategori);
                cmd.Parameters.AddWithValue("@deskripsi", kategoriBarang.Deskripsi);

                try
                {
                    // jalankan perintah UPDATE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            return result;
        }

        public int Delete(Kategori_Barang kategoriBarang)
        {
            int result = 0;

            // deklarasi perintah SQL
            string sql = @"delete from tabel_kategori_barang where id_Kategori = @id_kategori";

            // membuat objek command menggunakan blok using
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // mendaftarkan parameter dan mengeset nilainya
                cmd.Parameters.AddWithValue("@id_kategori", kategoriBarang.IdKategori);

                try
                {
                    // jalankan perintah DELETE dan tampung hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            return result;
        }

        public List<Kategori_Barang> ReadAll()
        {
            // membuat objek collection untuk menampung objek kategori barang
            List<Kategori_Barang> list = new List<Kategori_Barang>();

            try
            {
                // deklarasi perintah SQL
                string sql = @"select id_kategori, nama_kategori, deskripsi 
                               from kategori_barang order by nama_kategori";

                // membuat objek command menggunakan blok using
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // membuat objek dtr (data reader) untuk menampung result set
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // panggil method Read untuk mendapatkan baris dari result set
                        while (dtr.Read())
                        {
                            // proses konversi dari row result set ke object
                            Kategori_Barang kategoriBarang = new Kategori_Barang();
                            kategoriBarang.IdKategori = Convert.ToInt32(dtr["id_kategori"]);
                            kategoriBarang.NamaKategori = dtr["nama_kategori"].ToString();
                            kategoriBarang.Deskripsi = dtr["deskripsi"].ToString();

                            // tambahkan objek kategori barang ke dalam collection
                            list.Add(kategoriBarang);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
            }

            return list;
        }

        public List<Kategori_Barang> ReadByNama(string namaKategori)
        {
            // membuat objek collection untuk menampung objek kategori barang
            List<Kategori_Barang> list = new List<Kategori_Barang>();

            try
            {
                // deklarasi perintah SQL
                string sql = @"select id_kategori, nama_kategori, deskripsi 
                               from kategori_barang where nama_kategori like @nama_kategori order by nama_kategori";

                // membuat objek command menggunakan blok using
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // mendaftarkan parameter dan mengeset nilainya
                    cmd.Parameters.AddWithValue("@nama_kategori", string.Format("%{0}%", namaKategori));

                    // membuat objek dtr (data reader) untuk menampung result set
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // panggil method Read untuk mendapatkan baris dari result set
                        while (dtr.Read())
                        {
                            // proses konversi dari row result set ke object
                            Kategori_Barang kategoriBarang = new Kategori_Barang();
                            kategoriBarang.IdKategori = Convert.ToInt32(dtr["id_kategori"]);
                            kategoriBarang.NamaKategori = dtr["nama_kategori"].ToString();
                            kategoriBarang.Deskripsi = dtr["deskripsi"].ToString();

                            // tambahkan objek kategori barang ke dalam collection
                            list.Add(kategoriBarang);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.Print("ReadByNama error: {0}", ex.Message);
            }

            return list;
        }
    }
}