﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    internal class Transaksi_KeluarRepo
    {
        // Deklarasi objek koneksi untuk berinteraksi dengan database
        private MySqlConnection _conn;

        // Konstruktor untuk menginisialisasi objek koneksi berdasarkan DbContext yang diberikan
        public Transaksi_KeluarRepo(DbContext context)
        {
            _conn = context.Conn;
        }

        // Method untuk menambahkan data transaksi keluar ke dalam database
        public int Create(Transaksi_Keluar transaksi)
        {
            int result = 0;

            // Deklarasi query SQL untuk memasukkan data transaksi keluar
            string sql = @"INSERT INTO tabel_transaksi_keluar (id_transaksi_keluar, id_barang, id_pengguna, tanggal_keluar, jumlah, tujuan)
                            VALUES (@id_transaksi_keluar, @id_barang, @id_pengguna, @tanggal_keluar, @jumlah, @tujuan)";

            // Menggunakan blok using untuk memastikan cmd (MySqlCommand) dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter untuk mencegah SQL Injection dan mengeset nilai parameter
                cmd.Parameters.AddWithValue("@id_barang", transaksi.IdBarang);
                cmd.Parameters.AddWithValue("@id_pengguna", transaksi.IdPengguna);
                cmd.Parameters.AddWithValue("@tanggal_keluar", transaksi.TanggalKeluar);
                cmd.Parameters.AddWithValue("@jumlah", transaksi.Jumlah);
                cmd.Parameters.AddWithValue("@tujuan", transaksi.Tujuan);

                try
                {
                    // Menjalankan query INSERT untuk menyimpan data transaksi keluar ke dalam database
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika terjadi masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
            return result;
        }

        // Method untuk mengambil semua data transaksi keluar dari database
        public List<Transaksi_Keluar> ReadAll()
        {
            // Membuat list untuk menampung objek transaksi keluar
            List<Transaksi_Keluar> list = new List<Transaksi_Keluar>();

            // Query SQL untuk mengambil semua transaksi keluar, urut berdasarkan tanggal keluar
            string sql = @"SELECT id_transaksi_keluar, id_barang, id_pengguna, tanggal_keluar, jumlah, tujuan
                            FROM tabel_transaksi_keluar
                            ORDER BY tanggal_keluar DESC;";

            // Menggunakan blok using untuk memastikan cmd dan dtr dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                try
                {
                    // Eksekusi query dan mengambil hasilnya menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Menyimpan setiap baris hasil query ke dalam list sebagai objek Transaksi_Keluar
                        while (dtr.Read())
                        {
                            Transaksi_Keluar transaksi = new Transaksi_Keluar
                            {
                                IdTransaksiKeluar = Convert.ToInt32(dtr["id_transaksi_keluar"]),
                                IdBarang = Convert.ToInt32(dtr["id_barang"]),
                                IdPengguna = Convert.ToInt32(dtr["id_pengguna"]),
                                TanggalKeluar = Convert.ToDateTime(dtr["tanggal_keluar"]),
                                Jumlah = Convert.ToInt32(dtr["jumlah"]),
                                Tujuan = dtr["tujuan"].ToString()
                            };
                            // Menambahkan objek transaksi yang telah diisi ke dalam list
                            list.Add(transaksi);
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Menangani error jika terjadi masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
                }
            }

            // Mengembalikan list yang berisi semua data transaksi keluar
            return list;
        }

        // Method untuk memperbarui data transaksi keluar di database
        public int Update(Transaksi_Keluar transaksi)
        {
            int result = 0;

            // Query SQL untuk memperbarui data transaksi keluar berdasarkan id_transaksi_keluar
            string sql = @"UPDATE tabel_transaksi_keluar 
                           SET id_barang = @id_barang, id_pengguna = @id_pengguna, 
                               tanggal_keluar = @tanggal_keluar, jumlah = @jumlah, tujuan = @tujuan 
                           WHERE id_transaksi_keluar = @id_transaksi";

            // Menggunakan blok using untuk memastikan cmd dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter untuk mencegah SQL Injection dan mengeset nilai parameter
                cmd.Parameters.AddWithValue("@id_barang", transaksi.IdBarang);
                cmd.Parameters.AddWithValue("@id_pengguna", transaksi.IdPengguna);
                cmd.Parameters.AddWithValue("@tanggal_keluar", transaksi.TanggalKeluar);
                cmd.Parameters.AddWithValue("@jumlah", transaksi.Jumlah);
                cmd.Parameters.AddWithValue("@id_transaksi", transaksi.IdTransaksiKeluar);

                try
                {
                    // Menjalankan query UPDATE untuk memperbarui data transaksi keluar
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika terjadi masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
            return result;
        }

        // Method untuk menghapus data transaksi keluar dari database berdasarkan id_transaksi_keluar
        public int Delete(int idTransaksi)
        {
            int result = 0;

            // Query SQL untuk menghapus transaksi keluar berdasarkan id_transaksi_keluar
            string sql = @"DELETE FROM tabel_transaksi_keluar WHERE id_transaksi_keluar = @id_transaksi";

            // Menggunakan blok using untuk memastikan cmd dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter untuk mencegah SQL Injection dan mengeset nilai parameter
                cmd.Parameters.AddWithValue("@id_transaksi", idTransaksi);

                try
                {
                    // Menjalankan query DELETE untuk menghapus data transaksi keluar
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error jika terjadi masalah saat eksekusi query
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            // Mengembalikan jumlah baris yang terpengaruh (biasanya 1 jika sukses)
            return result;
        }
    }
}