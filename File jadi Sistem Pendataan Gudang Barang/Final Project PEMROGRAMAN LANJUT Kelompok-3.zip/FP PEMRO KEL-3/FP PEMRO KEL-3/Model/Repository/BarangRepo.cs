﻿using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    public class BarangRepository
    {
        // Deklarasi objek connection untuk menghubungkan aplikasi ke database
        private MySqlConnection _conn;

        // Constructor yang menerima objek DbContext untuk menginisialisasi koneksi
        public BarangRepository(DbContext context)
        {
            // Inisialisasi objek connection menggunakan koneksi dari context
            _conn = context.Conn;
        }

        // Method untuk menambah data Barang ke dalam database
        public int Create(Barang barang)
        {
            int result = 0;

            // SQL query untuk memasukkan data barang
            string sql = @"insert into tabel_barang (id_barang, nama_barang, deskripsi, harga_satuan, stok_tersedia, id_kategori) 
                           values (@id_barang, @nama_barang, @deskripsi, @harga_satuan, @stok_tersedia, @id_kategori)";

            // Menggunakan blok using untuk memastikan objek cmd dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter yang digunakan dalam query dan memberi nilai pada parameter
                cmd.Parameters.AddWithValue("@id_barang", barang.IdBarang);
                cmd.Parameters.AddWithValue("@nama_barang", barang.NamaBarang);
                cmd.Parameters.AddWithValue("@deskripsi", barang.Deskripsi);
                cmd.Parameters.AddWithValue("@harga_satuan", barang.HargaSatuan);
                cmd.Parameters.AddWithValue("@stok_tersedia", barang.Stok);
                cmd.Parameters.AddWithValue("@id_kategori", barang.IdKategori);


                try
                {
                    // Menjalankan query INSERT dan menyimpan hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Jika ada error, tampilkan pesan error pada output
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi (jumlah baris yang terpengaruh)
            return result;
        }

        // Method untuk mengupdate data barang di database
        public int Update(Barang barang)
        {
            int result = 0;

            // SQL query untuk mengupdate data barang berdasarkan IdBarang
            string sql = @"update tabel_barang set nama_barang = @nama_barang, deskripsi = @deskripsi, harga_satuan = @harga_satuan, 
                           stok_tersedia = @stok_tersedia where id_barang = @id_barang";

            // Menggunakan blok using untuk memastikan objek cmd dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter yang digunakan dalam query dan memberi nilai pada parameter
                cmd.Parameters.AddWithValue("@id_barang", barang.IdBarang);
                cmd.Parameters.AddWithValue("@nama_barang", barang.NamaBarang);
                cmd.Parameters.AddWithValue("@deskripsi", barang.Deskripsi);
                cmd.Parameters.AddWithValue("@harga_satuan", barang.HargaSatuan);
                cmd.Parameters.AddWithValue("@stok_tersedia", barang.Stok);
                cmd.Parameters.AddWithValue("@id_kategori", barang.IdKategori); // Namun, parameter ini tidak digunakan dalam query update


                try
                {
                    // Menjalankan query UPDATE dan menyimpan hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Jika ada error, tampilkan pesan error pada output
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi (jumlah baris yang terpengaruh)
            return result;
        }

        // Method untuk menghapus data barang dari database berdasarkan IdBarang
        public int Delete(Barang barang)
        {
            int result = 0;

            // SQL query untuk menghapus data barang berdasarkan IdBarang
            string sql = @"delete from tabel_barang where id_barang = @id_barang";

            // Menggunakan blok using untuk memastikan objek cmd dibersihkan setelah digunakan
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Menambahkan parameter yang digunakan dalam query dan memberi nilai pada parameter
                cmd.Parameters.AddWithValue("@id_barang", barang.IdBarang);

                try
                {
                    // Menjalankan query DELETE dan menyimpan hasilnya ke dalam variabel result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Jika ada error, tampilkan pesan error pada output
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi (jumlah baris yang terpengaruh)
            return result;
        }

        // Method untuk membaca semua data barang dari database
        public List<Barang> ReadAll()
        {
            // Membuat list untuk menampung objek barang
            List<Barang> list = new List<Barang>();

            try
            {
                // SQL query untuk mengambil semua data barang dari tabel barang
                string sql = @"select id_barang, nama_barang, deskripsi, harga_satuan, stok_tersedia, id_kategori 
                               from barang order by nama_barang";

                // Menggunakan blok using untuk memastikan objek cmd dan dtr dibersihkan setelah digunakan
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // Membaca hasil query menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Mengambil setiap baris dari hasil query dan mengonversinya ke objek Barang
                        while (dtr.Read())
                        {
                            Barang barang = new Barang();
                            barang.IdBarang = Convert.ToInt32(dtr["id_barang"]);
                            barang.NamaBarang = dtr["nama_barang"].ToString();
                            barang.Deskripsi = dtr["deskripsi"].ToString();
                            barang.HargaSatuan = Convert.ToDecimal(dtr["harga_satuan"]);
                            barang.Stok = Convert.ToInt32(dtr["stok_tersedia"]);
                            barang.IdKategori = Convert.ToInt32(dtr["id_kategori"]);


                            // Menambahkan objek barang ke dalam list
                            list.Add(barang);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Jika ada error, tampilkan pesan error pada output
                System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
            }

            // Mengembalikan list yang berisi semua data barang
            return list;
        }

        // Method untuk membaca data barang berdasarkan nama barang
        public List<Barang> ReadByNama(string namaBarang)
        {
            // Membuat list untuk menampung objek barang
            List<Barang> list = new List<Barang>();

            try
            {
                // SQL query untuk mengambil data barang yang nama barangnya sesuai dengan parameter
                string sql = @"select id_barang, nama_barang, harga_satuan, stok_tersedia, id_kategori, deskripsi 
                               from barang where nama_barang like @nama_barang order by nama_barang";

                // Menggunakan blok using untuk memastikan objek cmd dan dtr dibersihkan setelah digunakan
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // Menambahkan parameter yang digunakan dalam query dan memberi nilai pada parameter
                    cmd.Parameters.AddWithValue("@nama_barang", string.Format("%{0}%", namaBarang));

                    // Membaca hasil query menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Mengambil setiap baris dari hasil query dan mengonversinya ke objek Barang
                        while (dtr.Read())
                        {
                            Barang barang = new Barang();
                            barang.IdBarang = Convert.ToInt32(dtr["id_barang"]);
                            barang.NamaBarang = dtr["nama_barang"].ToString();
                            barang.Deskripsi = dtr["deskripsi"].ToString();
                            barang.HargaSatuan = Convert.ToDecimal(dtr["harga_satuan"]);
                            barang.Stok = Convert.ToInt32(dtr["stok_tersedia"]);
                            barang.IdKategori = Convert.ToInt32(dtr["id_kategori"]);


                            // Menambahkan objek barang ke dalam list
                            list.Add(barang);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Jika ada error, tampilkan pesan error pada output
                System.Diagnostics.Debug.Print("ReadByNama error: {0}", ex.Message);
            }

            // Mengembalikan list yang berisi data barang berdasarkan nama barang
            return list;
        }
    }
}