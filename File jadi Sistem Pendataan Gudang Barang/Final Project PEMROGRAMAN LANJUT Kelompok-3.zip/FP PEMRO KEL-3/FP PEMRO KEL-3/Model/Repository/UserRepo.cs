﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Context;

namespace FP_PEMRO_KEL_3.Model.Repository
{
    // Kelas UserRepository untuk menangani operasi CRUD (Create, Read, Update, Delete) pada entitas User
    public class UserRepository
    {
        // deklarasi objek connection untuk koneksi ke database MySQL
        private MySqlConnection _conn;

        // Konstruktor untuk menginisialisasi objek koneksi dengan DbContext
        public UserRepository(DbContext context)
        {
            // Menginisialisasi koneksi dengan menggunakan koneksi yang ada pada DbContext
            _conn = context.Conn;
        }

        // Metode untuk membuat entitas User baru dalam database
        public int Create(User user)
        {
            int result = 0;

            // Menyusun perintah SQL untuk memasukkan data pengguna baru
            string sql = @"insert into tabel_user (id_pengguna, nama_pengguna, username, sandi, role) 
                           values (@id_pengguna, @nama_pengguna, @username, @sandi, @role)";

            // Membuat objek command untuk mengeksekusi perintah SQL
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Mendaftarkan parameter SQL dan memberikan nilai sesuai dengan objek user yang diberikan
                cmd.Parameters.AddWithValue("@id_pengguna", user.IdPengguna);
                cmd.Parameters.AddWithValue("@nama_pengguna", user.NamaPengguna);
                cmd.Parameters.AddWithValue("@username", user.Username);
                cmd.Parameters.AddWithValue("@sandi", user.Sandi);
                cmd.Parameters.AddWithValue("@role", user.Role);

                try
                {
                    // Menjalankan perintah SQL INSERT dan menyimpan jumlah baris yang terpengaruh ke dalam result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error dan mencetak pesan kesalahan pada debug output
                    System.Diagnostics.Debug.Print("Create error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi INSERT (jumlah baris yang terpengaruh)
            return result;
        }

        // Metode untuk memperbarui data pengguna berdasarkan ID
        public int Update(User user)
        {
            int result = 0;

            // Menyusun perintah SQL untuk memperbarui data pengguna
            string sql = @"update tabel_user set nama_pengguna = @nama_pengguna, username = @username, sandi = @sandi, role = @role 
                           where id_pengguna = @id_pengguna";

            // Membuat objek command untuk mengeksekusi perintah SQL
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Mendaftarkan parameter SQL dan memberikan nilai sesuai dengan objek user yang diberikan
                cmd.Parameters.AddWithValue("@id_pengguna", user.IdPengguna);
                cmd.Parameters.AddWithValue("@nama_pengguna", user.NamaPengguna);
                cmd.Parameters.AddWithValue("@username", user.Username);
                cmd.Parameters.AddWithValue("@sandi", user.Sandi);
                cmd.Parameters.AddWithValue("@role", user.Role);

                try
                {
                    // Menjalankan perintah SQL UPDATE dan menyimpan jumlah baris yang terpengaruh ke dalam result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error dan mencetak pesan kesalahan pada debug output
                    System.Diagnostics.Debug.Print("Update error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi UPDATE (jumlah baris yang terpengaruh)
            return result;
        }

        // Metode untuk menghapus data pengguna berdasarkan ID
        public int Delete(User user)
        {
            int result = 0;

            // Menyusun perintah SQL untuk menghapus data pengguna berdasarkan ID
            string sql = @"delete from tabel_user where id_pengguna = @id_pengguna";

            // Membuat objek command untuk mengeksekusi perintah SQL
            using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
            {
                // Mendaftarkan parameter SQL dan memberikan nilai sesuai dengan ID pengguna yang akan dihapus
                cmd.Parameters.AddWithValue("@id_pengguna", user.IdPengguna);

                try
                {
                    // Menjalankan perintah SQL DELETE dan menyimpan jumlah baris yang terpengaruh ke dalam result
                    result = cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Menangani error dan mencetak pesan kesalahan pada debug output
                    System.Diagnostics.Debug.Print("Delete error: {0}", ex.Message);
                }
            }

            // Mengembalikan hasil operasi DELETE (jumlah baris yang terpengaruh)
            return result;
        }

        // Metode untuk membaca semua data pengguna dari database
        public List<Barang> ReadAll()
        {
            // Membuat objek collection untuk menampung data pengguna yang dibaca
            List<Barang> list = new List<Barang>();

            try
            {
                // Menyusun perintah SQL untuk memilih semua data pengguna
                string sql = @"select id_pengguna, nama_pengguna, username, sandi, role 
                               from user order by nama_pengguna";

                // Membuat objek command untuk mengeksekusi perintah SQL
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // Membaca hasil query menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Melakukan iterasi untuk setiap baris yang ditemukan
                        while (dtr.Read())
                        {
                            // Membuat objek User dan memetakan hasil query ke dalam objek tersebut
                            User user = new User();
                            user.IdPengguna = Convert.ToInt32(dtr["id_pengguna"]);
                            user.NamaPengguna = dtr["nama_pengguna"].ToString();
                            user.Username = dtr["username"].ToString();
                            user.Sandi = dtr["sandi"].ToString();
                            user.Role = dtr["role"].ToString();

                            // Menambahkan objek user ke dalam collection
                            // list.Add(user); // Seharusnya baris ini ada, namun belum diaktifkan di kode yang diberikan
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Menangani error dan mencetak pesan kesalahan pada debug output
                System.Diagnostics.Debug.Print("ReadAll error: {0}", ex.Message);
            }

            // Mengembalikan hasil (list kosong jika gagal atau data pengguna yang berhasil dibaca)
            return list;
        }

        // Metode untuk membaca data pengguna berdasarkan nama
        public List<User> ReadByNama(string namaPengguna)
        {
            // Membuat objek collection untuk menampung data pengguna yang dibaca
            List<User> list = new List<User>();

            try
            {
                // Menyusun perintah SQL untuk memilih data pengguna berdasarkan nama
                string sql = @"select id_pengguna, nama_pengguna, username, sandi, role 
                               from user where nama_pengguna like @nama_pengguna order by nama_pengguna";

                // Membuat objek command untuk mengeksekusi perintah SQL
                using (MySqlCommand cmd = new MySqlCommand(sql, _conn))
                {
                    // Mendaftarkan parameter SQL dan memberikan nilai untuk pencocokan nama pengguna
                    cmd.Parameters.AddWithValue("@nama_pengguna", string.Format("%{0}%", namaPengguna));

                    // Membaca hasil query menggunakan MySqlDataReader
                    using (MySqlDataReader dtr = cmd.ExecuteReader())
                    {
                        // Melakukan iterasi untuk setiap baris yang ditemukan
                        while (dtr.Read())
                        {
                            // Membuat objek User dan memetakan hasil query ke dalam objek tersebut
                            User user = new User();
                            user.IdPengguna = Convert.ToInt32(dtr["id_pengguna"]);
                            user.NamaPengguna = dtr["nama_pengguna"].ToString();
                            user.Username = dtr["username"].ToString();
                            user.Sandi = dtr["sandi"].ToString();
                            user.Role = dtr["role"].ToString();

                            // Menambahkan objek user ke dalam collection
                            list.Add(user);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Menangani error dan mencetak pesan kesalahan pada debug output
                System.Diagnostics.Debug.Print("ReadByNama error: {0}", ex.Message);
            }

            // Mengembalikan hasil (list dengan pengguna yang ditemukan berdasarkan nama)
            return list;
        }
    }
}