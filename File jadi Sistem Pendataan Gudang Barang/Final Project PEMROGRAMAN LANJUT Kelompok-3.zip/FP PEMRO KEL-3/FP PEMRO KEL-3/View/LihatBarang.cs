﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;
using FP_PEMRO_KEL_3.Controller;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace FP_PEMRO_KEL_3
{
    public partial class LihatBarang : Form
    {
        public LihatBarang()
        {
            InitializeComponent();
            InisialisasiListView();
            TampilkanData();
        }
        private void InisialisasiListView()
        {
            lvwBarang.View = View.Details;
            lvwBarang.FullRowSelect = true;
            lvwBarang.GridLines = true;

            lvwBarang.Columns.Add("ID", 30, HorizontalAlignment.Center);
            lvwBarang.Columns.Add("Nama Barang", 150, HorizontalAlignment.Center);
            lvwBarang.Columns.Add("ID KATEGORI", 90, HorizontalAlignment.Center);
            lvwBarang.Columns.Add("Stok", 80, HorizontalAlignment.Center);
            lvwBarang.Columns.Add("Harga Satuan", 100, HorizontalAlignment.Center);
            lvwBarang.Columns.Add("Deskripsi", 180, HorizontalAlignment.Center);
        }
        private void lvwBarang_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                // Isi form dengan data dari item yang dipilih
                txtNamaBarang.Text = e.Item.SubItems[1].Text; // Nama Barang
                cmbIDkategori.Text = e.Item.SubItems[2].Text; // ID Kategori
                txtStok.Text = e.Item.SubItems[3].Text; // Stok
                txtHarga.Text = e.Item.SubItems[4].Text; // Harga Satuan
                txtDeskripsi.Text = e.Item.SubItems[5].Text; // Deskripsi
            }
        }



        private void btnCari_Click(object sender, EventArgs e)
        {
            string keyword = txtCari.Text; // Ambil input keyword dari pengguna

            if (string.IsNullOrWhiteSpace(keyword))
            {
                MessageBox.Show("Masukkan nama barang untuk mencari.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lvwBarang.Items.Clear(); // Bersihkan ListView sebelum menampilkan hasil pencarian

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Query untuk mencari data berdasarkan nama barang
                    string query = "SELECT * FROM tabel_barang WHERE nama_barang LIKE @keyword";

                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%"); // Parameter pencarian dengan LIKE

                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                // Buat item ListView berdasarkan data dari database
                                ListViewItem item = new ListViewItem(reader["id_barang"].ToString());
                                item.SubItems.Add(reader["nama_barang"].ToString());
                                item.SubItems.Add(reader["id_kategori"].ToString());
                                item.SubItems.Add(reader["stok_tersedia"].ToString());
                                item.SubItems.Add(reader["harga_satuan"].ToString());
                                item.SubItems.Add(reader["deskripsi"].ToString());

                                // Tambahkan item ke ListView
                                lvwBarang.Items.Add(item);
                            }
                        }
                    }

                    // Jika tidak ada data ditemukan
                    if (lvwBarang.Items.Count == 0)
                    {
                        MessageBox.Show("Data barang tidak ditemukan.", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void TampilkanData()
        {
            lvwBarang.Items.Clear(); // Bersihkan ListView sebelum menambahkan data baru

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = "SELECT * FROM tabel_barang";
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Buat item ListView
                            ListViewItem item = new ListViewItem(reader["id_barang"].ToString());
                            item.SubItems.Add(reader["nama_barang"].ToString());
                            item.SubItems.Add(reader["id_kategori"].ToString());
                            item.SubItems.Add(reader["stok_tersedia"].ToString());
                            item.SubItems.Add(reader["harga_satuan"].ToString());
                            item.SubItems.Add(reader["deskripsi"].ToString());

                            // Tambahkan item ke ListView
                            lvwBarang.Items.Add(item);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnTampilkan_Click(object sender, EventArgs e)
        {
            TampilkanData();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (lvwBarang.SelectedItems.Count > 0)
            {
                // Ambil ID dari item yang dipilih
                string idSupplier = lvwBarang.SelectedItems[0].Text;

                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        string query = "DELETE FROM tabel_barang WHERE id_barang = @id_barang";
                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            cmd.Parameters.AddWithValue("@id_barang", idSupplier);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil dihapus!");
                                TampilkanData(); // Perbarui ListView
                            }
                            else
                            {
                                MessageBox.Show("Data gagal dihapus.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Pilih data yang ingin dihapus terlebih dahulu.");
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string NamaBarang = txtNamaBarang.Text;
            string Stok = txtStok.Text;
            string Deskripsi = txtDeskripsi.Text;
            string IdKategori = cmbIDkategori.Text;

            decimal HargaSatuan;

            // Cek apakah txtHarga berisi angka desimal yang valid
            if (!decimal.TryParse(txtHarga.Text, out HargaSatuan))
            {
                MessageBox.Show("Harga satuan tidak valid. Pastikan nilai harga sesuai dengan format angka.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = @"INSERT INTO tabel_barang (nama_barang, stok_tersedia, deskripsi, id_kategori, harga_satuan) 
                             VALUES (@nama_barang, @stok_tersedia, @deskripsi, @id_kategori, @harga_satuan)";

                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        cmd.Parameters.AddWithValue("@nama_barang", NamaBarang);
                        cmd.Parameters.AddWithValue("@stok_tersedia", Stok);
                        cmd.Parameters.AddWithValue("@deskripsi", Deskripsi);
                        cmd.Parameters.AddWithValue("@id_kategori", IdKategori);
                        cmd.Parameters.AddWithValue("@harga_satuan", HargaSatuan);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data berhasil disimpan!");
                        }
                        else
                        {
                            MessageBox.Show("Data gagal disimpan.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (lvwBarang.SelectedItems.Count > 0)
            {
                string idBarang = lvwBarang.SelectedItems[0].Text;
                string namaBarang = txtNamaBarang.Text;
                string stok = txtStok.Text;
                string deskripsi = txtDeskripsi.Text;
                string idKategori = cmbIDkategori.Text;

                decimal hargaSatuan;

                // Cek apakah txtHarga berisi angka desimal yang valid
                if (!decimal.TryParse(txtHarga.Text, out hargaSatuan))
                {
                    MessageBox.Show("Harga satuan tidak valid. Pastikan nilai harga sesuai dengan format angka.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        string query = @"UPDATE tabel_barang 
                                 SET nama_barang = @nama_barang, 
                                     deskripsi = @deskripsi, 
                                     harga_satuan = @harga_satuan, 
                                     stok_tersedia = @stok_tersedia 
                                 WHERE id_barang = @id_barang";

                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            cmd.Parameters.AddWithValue("@nama_barang", namaBarang);
                            cmd.Parameters.AddWithValue("@deskripsi", deskripsi);
                            cmd.Parameters.AddWithValue("@harga_satuan", hargaSatuan);
                            cmd.Parameters.AddWithValue("@stok_tersedia", stok);
                            cmd.Parameters.AddWithValue("@id_barang", idBarang);

                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil diperbarui!");
                                TampilkanData(); // Refresh ListView
                            }
                            else
                            {
                                MessageBox.Show("Data gagal diperbarui.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
    }

}