﻿namespace FP_PEMRO_KEL_3
{
    partial class Gudang_Barang__Transaksi_Keluar_
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.txtIDbarang = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtJumlah = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTujuan = new System.Windows.Forms.TextBox();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.IDpengguna = new System.Windows.Forms.TextBox();
            this.btnTampil = new System.Windows.Forms.Button();
            this.btnHapus = new System.Windows.Forms.Button();
            this.lvwTransaksiKeluar = new System.Windows.Forms.ListView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "ID Barang";
            // 
            // txtIDbarang
            // 
            this.txtIDbarang.Location = new System.Drawing.Point(16, 53);
            this.txtIDbarang.Name = "txtIDbarang";
            this.txtIDbarang.Size = new System.Drawing.Size(175, 22);
            this.txtIDbarang.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 16);
            this.label5.TabIndex = 8;
            this.label5.Text = "Jumlah";
            // 
            // txtJumlah
            // 
            this.txtJumlah.Location = new System.Drawing.Point(17, 125);
            this.txtJumlah.Name = "txtJumlah";
            this.txtJumlah.Size = new System.Drawing.Size(174, 22);
            this.txtJumlah.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tujuan";
            // 
            // txtTujuan
            // 
            this.txtTujuan.Location = new System.Drawing.Point(16, 195);
            this.txtTujuan.Name = "txtTujuan";
            this.txtTujuan.Size = new System.Drawing.Size(173, 22);
            this.txtTujuan.TabIndex = 11;
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(17, 272);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(174, 23);
            this.btnSimpan.TabIndex = 12;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(17, 317);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(172, 23);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(226, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "ID Pengguna";
            // 
            // IDpengguna
            // 
            this.IDpengguna.Location = new System.Drawing.Point(229, 28);
            this.IDpengguna.Name = "IDpengguna";
            this.IDpengguna.Size = new System.Drawing.Size(245, 22);
            this.IDpengguna.TabIndex = 15;
            // 
            // btnTampil
            // 
            this.btnTampil.Location = new System.Drawing.Point(504, 28);
            this.btnTampil.Name = "btnTampil";
            this.btnTampil.Size = new System.Drawing.Size(114, 28);
            this.btnTampil.TabIndex = 17;
            this.btnTampil.Text = "Tampilkan Data";
            this.btnTampil.UseVisualStyleBackColor = true;
            this.btnTampil.Click += new System.EventHandler(this.btnTampil_Click);
            // 
            // btnHapus
            // 
            this.btnHapus.Location = new System.Drawing.Point(644, 28);
            this.btnHapus.Name = "btnHapus";
            this.btnHapus.Size = new System.Drawing.Size(104, 28);
            this.btnHapus.TabIndex = 18;
            this.btnHapus.Text = "Hapus";
            this.btnHapus.UseVisualStyleBackColor = true;
            this.btnHapus.Click += new System.EventHandler(this.btnHapus_Click);
            // 
            // lvwTransaksiKeluar
            // 
            this.lvwTransaksiKeluar.HideSelection = false;
            this.lvwTransaksiKeluar.Location = new System.Drawing.Point(9, 21);
            this.lvwTransaksiKeluar.Name = "lvwTransaksiKeluar";
            this.lvwTransaksiKeluar.Size = new System.Drawing.Size(688, 361);
            this.lvwTransaksiKeluar.TabIndex = 19;
            this.lvwTransaksiKeluar.UseCompatibleStateImageBehavior = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lvwTransaksiKeluar);
            this.groupBox1.Location = new System.Drawing.Point(220, 61);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(705, 388);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Data Transaksi Keluar";
            // 
            // Gudang_Barang__Transaksi_Keluar_
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 461);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnHapus);
            this.Controls.Add(this.btnTampil);
            this.Controls.Add(this.IDpengguna);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.txtTujuan);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtJumlah);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtIDbarang);
            this.Controls.Add(this.label2);
            this.Name = "Gudang_Barang__Transaksi_Keluar_";
            this.Text = "Gudang Barang (Transaksi Keluar)";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIDbarang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtJumlah;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTujuan;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox IDpengguna;
        private System.Windows.Forms.Button btnTampil;
        private System.Windows.Forms.Button btnHapus;
        private System.Windows.Forms.ListView lvwTransaksiKeluar;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}