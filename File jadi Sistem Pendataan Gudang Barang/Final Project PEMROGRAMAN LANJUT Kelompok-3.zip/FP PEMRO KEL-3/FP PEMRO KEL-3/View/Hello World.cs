﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FP_PEMRO_KEL_3.Model.Entity;
using MySql.Data.MySqlClient;

namespace FP_PEMRO_KEL_3
{
    public partial class Hello_World : Form
    {
        public Hello_World()
        {
            InitializeComponent();
        }

        private void btnLihat_Click(object sender, EventArgs e)
        {
            LihatBarang form = new LihatBarang();
            form.Show();
        }

        private void btnTransaksiMasuk_Click(object sender, EventArgs e)
        {
            Transaksi_Masuk_ form = new Transaksi_Masuk_();
            form.Show();
        }

        private void btnTransaksiKeluar_Click(object sender, EventArgs e)
        {
            Gudang_Barang__Transaksi_Keluar_ form = new Gudang_Barang__Transaksi_Keluar_();
            form.Show();

        }

        private void btnSupplier_Click(object sender, EventArgs e)
        {
            Suplier form = new Suplier();
            form.Show();
        }
    }
}
