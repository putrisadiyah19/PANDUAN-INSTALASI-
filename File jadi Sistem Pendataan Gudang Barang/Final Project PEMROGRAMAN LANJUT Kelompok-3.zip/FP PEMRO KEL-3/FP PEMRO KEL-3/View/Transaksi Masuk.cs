﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace FP_PEMRO_KEL_3
{
    public partial class Transaksi_Masuk_ : Form
    {
        public Transaksi_Masuk_()
        {
            InitializeComponent();
            InisialisasiListView();
            TampilkanData();
        }
        private void InisialisasiListView()
        {
            lvwTransaksiMasuk.View = View.Details;
            lvwTransaksiMasuk.FullRowSelect = true;
            lvwTransaksiMasuk.GridLines = true;

            lvwTransaksiMasuk.Columns.Add("ID", 30, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("ID Pengguna", 80, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("ID Barang", 80, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("ID Supplier", 80, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("Tanggal Masuk", 150, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("Jumlah", 50, HorizontalAlignment.Center);
            lvwTransaksiMasuk.Columns.Add("Harga Total", 120, HorizontalAlignment.Center);
        }
        private void ResetForm()
        {
            txtIDpengguna.Clear();
            txtIDbarang.Clear();
            txtIDsupplier.Clear();
            txtJumlah.Clear();
          
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string IdPengguna = txtIDpengguna.Text;
            string IdBarang = txtIDbarang.Text;
            string IdSupplier = txtIDsupplier.Text;
            string TanggalMasuk = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // Otomatis ambil tanggal dan waktu saat ini
            string Jumlah = txtJumlah.Text;
            decimal hargaTotal = 0;

            // Ambil harga satuan dari tabel_barang berdasarkan id_barang
            decimal hargaSatuan = GetHargaSatuan(IdBarang);

            if (hargaSatuan != 0)
            {
                // Hitung harga total
                if (decimal.TryParse(Jumlah, out decimal jumlah))
                {
                    hargaTotal = hargaSatuan * jumlah;
                }
                else
                {
                    MessageBox.Show("Jumlah harus berupa angka.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                MessageBox.Show("Harga satuan tidak ditemukan.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Simpan transaksi masuk ke tabel_transaksi_masuk
            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Mulai transaksi database
                    using (var transaction = context.Conn.BeginTransaction())
                    {
                        try
                        {
                            // 1. Simpan transaksi masuk ke tabel_transaksi_masuk
                            string queryTransaksi = @"INSERT INTO tabel_transaksi_masuk 
                                           (id_pengguna, id_barang, id_supplier, tanggal_masuk, jumlah, harga_total)
                                           VALUES (@id_pengguna, @id_barang, @id_supplier, @tanggal_masuk, @jumlah, @harga_total)";

                            using (MySqlCommand cmdTransaksi = new MySqlCommand(queryTransaksi, context.Conn, transaction))
                            {
                                cmdTransaksi.Parameters.AddWithValue("@id_pengguna", IdPengguna);
                                cmdTransaksi.Parameters.AddWithValue("@id_barang", IdBarang);
                                cmdTransaksi.Parameters.AddWithValue("@id_supplier", IdSupplier);
                                cmdTransaksi.Parameters.AddWithValue("@tanggal_masuk", TanggalMasuk);
                                cmdTransaksi.Parameters.AddWithValue("@jumlah", Jumlah);
                                cmdTransaksi.Parameters.AddWithValue("@harga_total", hargaTotal);

                                cmdTransaksi.ExecuteNonQuery();
                            }

                            // 2. Tambah stok barang di tabel_barang
                            string queryUpdateStok = @"UPDATE tabel_barang 
                                           SET stok_tersedia = stok_tersedia + @jumlah 
                                           WHERE id_barang = @id_barang";

                            using (MySqlCommand cmdUpdateStok = new MySqlCommand(queryUpdateStok, context.Conn, transaction))
                            {
                                cmdUpdateStok.Parameters.AddWithValue("@jumlah", Jumlah);
                                cmdUpdateStok.Parameters.AddWithValue("@id_barang", IdBarang);

                                int rowsAffected = cmdUpdateStok.ExecuteNonQuery();

                                if (rowsAffected == 0)
                                {
                                    // Jika tidak ada baris yang diperbarui, ID barang mungkin tidak ditemukan
                                    throw new Exception("Barang tidak ditemukan atau stok tidak dapat diperbarui.");
                                }
                            }

                            // Commit transaksi jika semua berhasil
                            transaction.Commit();
                            MessageBox.Show("Transaksi masuk berhasil disimpan dan stok barang diperbarui!");
                        }
                        catch (Exception ex)
                        {
                            // Rollback transaksi jika terjadi kesalahan
                            transaction.Rollback();
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // Fungsi untuk mendapatkan harga satuan dari tabel_barang
        private decimal GetHargaSatuan(string idBarang)
        {
            decimal hargaSatuan = 0;

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = "SELECT harga_satuan FROM tabel_barang WHERE id_barang = @id_barang";
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        cmd.Parameters.AddWithValue("@id_barang", idBarang);
                        object result = cmd.ExecuteScalar();
                        if (result != null && decimal.TryParse(result.ToString(), out hargaSatuan))
                        {
                            return hargaSatuan;
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            return hargaSatuan;
        }


        private void TampilkanData()
        {
            lvwTransaksiMasuk.Items.Clear(); // Bersihkan ListView sebelum menambahkan data baru

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = "SELECT * FROM tabel_transaksi_masuk";
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Buat item ListView
                            ListViewItem item = new ListViewItem(reader["id_transaksi_masuk"].ToString());
                            item.SubItems.Add(reader["id_pengguna"].ToString());
                            item.SubItems.Add(reader["id_barang"].ToString());
                            item.SubItems.Add(reader["id_supplier"].ToString());
                            item.SubItems.Add(reader["tanggal_masuk"].ToString());
                            item.SubItems.Add(reader["jumlah"].ToString());
                            item.SubItems.Add(reader["harga_total"].ToString());

                            // Tambahkan item ke ListView
                            lvwTransaksiMasuk.Items.Add(item);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (lvwTransaksiMasuk.SelectedItems.Count > 0)
            {
                // Ambil ID dari item yang dipilih
                string id_transaksi_masuk = lvwTransaksiMasuk.SelectedItems[0].Text;

                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        string query = "DELETE FROM tabel_transaksi_masuk WHERE id_transaksi_masuk = @id_transaksi_masuk";
                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            cmd.Parameters.AddWithValue("@id_transaksi_masuk", id_transaksi_masuk);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil dihapus!");
                                TampilkanData(); // Perbarui ListView
                            }
                            else
                            {
                                MessageBox.Show("Data gagal dihapus.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void btnTampilkan_Click(object sender, EventArgs e)
        {
            TampilkanData();
        }
    }
}
