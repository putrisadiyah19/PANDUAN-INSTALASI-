﻿namespace FP_PEMRO_KEL_3
{
    partial class Hello_World
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnLihat = new System.Windows.Forms.Button();
            this.btnTransaksiMasuk = new System.Windows.Forms.Button();
            this.btnTransaksiKeluar = new System.Windows.Forms.Button();
            this.btnSupplier = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(313, 95);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hello :3";
            // 
            // btnLihat
            // 
            this.btnLihat.Location = new System.Drawing.Point(103, 212);
            this.btnLihat.Name = "btnLihat";
            this.btnLihat.Size = new System.Drawing.Size(127, 33);
            this.btnLihat.TabIndex = 1;
            this.btnLihat.Text = "Lihat Barang";
            this.btnLihat.UseVisualStyleBackColor = true;
            this.btnLihat.Click += new System.EventHandler(this.btnLihat_Click);
            // 
            // btnTransaksiMasuk
            // 
            this.btnTransaksiMasuk.Location = new System.Drawing.Point(245, 212);
            this.btnTransaksiMasuk.Name = "btnTransaksiMasuk";
            this.btnTransaksiMasuk.Size = new System.Drawing.Size(143, 33);
            this.btnTransaksiMasuk.TabIndex = 2;
            this.btnTransaksiMasuk.Text = "Transaksi Masuk";
            this.btnTransaksiMasuk.UseVisualStyleBackColor = true;
            this.btnTransaksiMasuk.Click += new System.EventHandler(this.btnTransaksiMasuk_Click);
            // 
            // btnTransaksiKeluar
            // 
            this.btnTransaksiKeluar.Location = new System.Drawing.Point(403, 212);
            this.btnTransaksiKeluar.Name = "btnTransaksiKeluar";
            this.btnTransaksiKeluar.Size = new System.Drawing.Size(127, 33);
            this.btnTransaksiKeluar.TabIndex = 3;
            this.btnTransaksiKeluar.Text = "Transaksi Keluar";
            this.btnTransaksiKeluar.UseVisualStyleBackColor = true;
            this.btnTransaksiKeluar.Click += new System.EventHandler(this.btnTransaksiKeluar_Click);
            // 
            // btnSupplier
            // 
            this.btnSupplier.Location = new System.Drawing.Point(551, 212);
            this.btnSupplier.Name = "btnSupplier";
            this.btnSupplier.Size = new System.Drawing.Size(127, 33);
            this.btnSupplier.TabIndex = 4;
            this.btnSupplier.Text = "Menu Supplier";
            this.btnSupplier.UseVisualStyleBackColor = true;
            this.btnSupplier.Click += new System.EventHandler(this.btnSupplier_Click);
            // 
            // Hello_World
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSupplier);
            this.Controls.Add(this.btnTransaksiKeluar);
            this.Controls.Add(this.btnTransaksiMasuk);
            this.Controls.Add(this.btnLihat);
            this.Controls.Add(this.label1);
            this.Name = "Hello_World";
            this.Text = "Gudang Barang";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLihat;
        private System.Windows.Forms.Button btnTransaksiMasuk;
        private System.Windows.Forms.Button btnTransaksiKeluar;
        private System.Windows.Forms.Button btnSupplier;
    }
}