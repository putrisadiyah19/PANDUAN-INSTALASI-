﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FP_PEMRO_KEL_3
{
    public partial class Gudang_Barang__Transaksi_Keluar_ : Form
    {
        public Gudang_Barang__Transaksi_Keluar_()
        {
            InitializeComponent();
            InisialisasiListView();
            TampilkanData();
        }
        private void InisialisasiListView()
        {
            lvwTransaksiKeluar.View = View.Details;
            lvwTransaksiKeluar.FullRowSelect = true;
            lvwTransaksiKeluar.GridLines = true;

            lvwTransaksiKeluar.Columns.Add("ID", 30, HorizontalAlignment.Center);
            lvwTransaksiKeluar.Columns.Add("ID Pengguna", 80, HorizontalAlignment.Center);
            lvwTransaksiKeluar.Columns.Add("ID Barang", 80, HorizontalAlignment.Center);
            lvwTransaksiKeluar.Columns.Add("Tanggal Keluar", 150, HorizontalAlignment.Center);
            lvwTransaksiKeluar.Columns.Add("Jumlah", 50, HorizontalAlignment.Center);
            lvwTransaksiKeluar.Columns.Add("Tujuan", 120, HorizontalAlignment.Center);
        }
        private void ResetForm()
        {
            txtIDbarang.Clear();
            txtJumlah.Clear();
            txtTujuan.Clear();
            IDpengguna.Clear();
        }
        private void TampilkanData()
        {
            lvwTransaksiKeluar.Items.Clear(); // Bersihkan ListView sebelum menambahkan data baru

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = "SELECT * FROM tabel_transaksi_keluar";
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Buat item ListView
                            ListViewItem item = new ListViewItem(reader["id_transaksi_keluar"].ToString());
                            item.SubItems.Add(reader["id_pengguna"].ToString());
                            item.SubItems.Add(reader["id_barang"].ToString());
                            item.SubItems.Add(reader["tanggal_keluar"].ToString());
                            item.SubItems.Add(reader["jumlah"].ToString());
                            item.SubItems.Add(reader["tujuan"].ToString());

                            // Tambahkan item ke ListView
                            lvwTransaksiKeluar.Items.Add(item);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string IdPengguna = IDpengguna.Text;
            string IdBarang = txtIDbarang.Text;
            string TanggalKeluar = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // Otomatis ambil tanggal dan waktu saat ini
            string Jumlah = txtJumlah.Text;
            string Tujuan = txtTujuan.Text;

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Mulai transaksi
                    using (var transaction = context.Conn.BeginTransaction())
                    {
                        try
                        {
                            // 1. Simpan transaksi keluar ke tabel_transaksi_keluar
                            string queryTransaksi = @"INSERT INTO tabel_transaksi_keluar 
                                               (id_pengguna, id_barang, tanggal_keluar, jumlah, tujuan)
                                               VALUES (@id_pengguna, @id_barang, @tanggal_keluar, @jumlah, @tujuan)";

                            using (MySqlCommand cmdTransaksi = new MySqlCommand(queryTransaksi, context.Conn, transaction))
                            {
                                cmdTransaksi.Parameters.AddWithValue("@id_pengguna", IdPengguna);
                                cmdTransaksi.Parameters.AddWithValue("@id_barang", IdBarang);
                                cmdTransaksi.Parameters.AddWithValue("@tanggal_keluar", TanggalKeluar);
                                cmdTransaksi.Parameters.AddWithValue("@jumlah", Jumlah);
                                cmdTransaksi.Parameters.AddWithValue("@tujuan", Tujuan);

                                cmdTransaksi.ExecuteNonQuery();
                            }

                            // 2. Kurangi stok barang di tabel_barang
                            string queryUpdateStok = @"UPDATE tabel_barang 
                                               SET stok_tersedia = stok_tersedia - @jumlah 
                                               WHERE id_barang = @id_barang";

                            using (MySqlCommand cmdUpdateStok = new MySqlCommand(queryUpdateStok, context.Conn, transaction))
                            {
                                cmdUpdateStok.Parameters.AddWithValue("@jumlah", Jumlah);
                                cmdUpdateStok.Parameters.AddWithValue("@id_barang", IdBarang);

                                int rowsAffected = cmdUpdateStok.ExecuteNonQuery();

                                if (rowsAffected == 0)
                                {
                                    // Jika tidak ada baris yang diperbarui, ID barang mungkin tidak ditemukan
                                    throw new Exception("Barang tidak ditemukan atau stok tidak dapat diperbarui.");
                                }
                            }

                            // 3. Validasi stok tidak boleh negatif
                            string queryCekStok = @"SELECT stok_tersedia FROM tabel_barang WHERE id_barang = @id_barang";
                            using (MySqlCommand cmdCekStok = new MySqlCommand(queryCekStok, context.Conn, transaction))
                            {
                                cmdCekStok.Parameters.AddWithValue("@id_barang", IdBarang);
                                object stokTersedia = cmdCekStok.ExecuteScalar();

                                if (stokTersedia != null && Convert.ToInt32(stokTersedia) < 0)
                                {
                                    throw new Exception("Stok barang tidak mencukupi.");
                                }
                            }

                            // Commit transaksi jika semuanya berhasil
                            transaction.Commit();
                            MessageBox.Show("Transaksi berhasil disimpan dan stok diperbarui!");
                        }
                        catch (Exception ex)
                        {
                            // Rollback transaksi jika terjadi kesalahan
                            transaction.Rollback();
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnTampil_Click(object sender, EventArgs e)
        {
            TampilkanData();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (lvwTransaksiKeluar.SelectedItems.Count > 0)
            {
                // Ambil ID dari item yang dipilih
                string id_transaksi_keluar = lvwTransaksiKeluar.SelectedItems[0].Text;

                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        string query = "DELETE FROM tabel_transaksi_keluar WHERE id_transaksi_keluar = @id_transaksi_keluar";
                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            cmd.Parameters.AddWithValue("@id_transaksi_keluar", id_transaksi_keluar);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil dihapus!");
                                TampilkanData(); // Perbarui ListView
                            }
                            else
                            {
                                MessageBox.Show("Data gagal dihapus.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
    }
}

        
