﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Context;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace FP_PEMRO_KEL_3
{
    public partial class Suplier : Form
    {
        public Suplier()
        {
            InitializeComponent();
            InisialisasiListView();
            TampilkanData();
        }
        private void InisialisasiListView()
        {
            lvwSupplier.View = View.Details;
            lvwSupplier.FullRowSelect = true;
            lvwSupplier.GridLines = true;

            lvwSupplier.Columns.Add("ID", 30, HorizontalAlignment.Center);
            lvwSupplier.Columns.Add("Nama", 91, HorizontalAlignment.Center);
            lvwSupplier.Columns.Add("Alamat", 200, HorizontalAlignment.Center);
            lvwSupplier.Columns.Add("Email", 150, HorizontalAlignment.Center);
            lvwSupplier.Columns.Add("Kontak", 91, HorizontalAlignment.Center);

        }
        private void ResetForm()
        {
            txtNama.Clear();
            txtAlamat.Clear();
            txtEmail.Clear();
            txtKontak.Clear();
        }
        private void lvwSupplier_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                // Isi form dengan data dari item yang dipilih
                txtNama.Text = e.Item.SubItems[1].Text; // Nama Supplier
                txtAlamat.Text = e.Item.SubItems[2].Text; // Alamat
                txtEmail.Text = e.Item.SubItems[3].Text; // Email
                txtKontak.Text = e.Item.SubItems[4].Text; // Kontak

            }
        }

        private void TampilkanData()
        {
            lvwSupplier.Items.Clear(); // Bersihkan ListView sebelum menambahkan data baru

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    string query = "SELECT * FROM tabel_supplier";
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            // Buat item ListView
                            ListViewItem item = new ListViewItem(reader["id_Supplier"].ToString());
                            item.SubItems.Add(reader["nama_supplier"].ToString());
                            item.SubItems.Add(reader["alamat"].ToString());
                            item.SubItems.Add(reader["email"].ToString());
                            item.SubItems.Add(reader["kontak"].ToString());

                            // Tambahkan item ke ListView
                            lvwSupplier.Items.Add(item);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }


        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string NamaSupplier = txtNama.Text;
            string Alamat = txtAlamat.Text;
            string Email = txtEmail.Text;
            string Kontak = txtKontak.Text;
            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Query untuk menyimpan data ke tabel_user
                    string query = @"insert into tabel_supplier (nama_supplier, alamat,email,kontak) values (@nama_supplier,@alamat,@email,@kontak)";

                    // Membuat MySqlCommand dengan koneksi dari DbContext
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        // Menambahkan parameter
                        cmd.Parameters.AddWithValue("@nama_supplier", NamaSupplier);
                        cmd.Parameters.AddWithValue("@alamat", Alamat);
                        cmd.Parameters.AddWithValue("@email", Email);
                        cmd.Parameters.AddWithValue("@kontak", Kontak);

                        // Menjalankan query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data berhasil disimpan!");
                        }
                        else
                        {
                            MessageBox.Show("Data gagal disimpan.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btnHapus_Click(object sender, EventArgs e)
        {
            if (lvwSupplier.SelectedItems.Count > 0)
            {
                // Ambil ID dari item yang dipilih
                string idSupplier = lvwSupplier.SelectedItems[0].Text;

                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        string query = "DELETE FROM tabel_supplier WHERE id_Supplier = @id_Supplier";
                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            cmd.Parameters.AddWithValue("@id_Supplier", idSupplier);
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil dihapus!");
                                TampilkanData(); // Perbarui ListView
                            }
                            else
                            {
                                MessageBox.Show("Data gagal dihapus.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Pilih data yang ingin dihapus terlebih dahulu.");
            }
        }

        private void btnTampil_Click(object sender, EventArgs e)
        {
            TampilkanData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Pastikan ada item yang dipilih di ListView
            if (lvwSupplier.SelectedItems.Count > 0)
            {
                // Ambil ID Supplier yang dipilih
                string idSupplier = lvwSupplier.SelectedItems[0].Text;

                // Ambil data dari form
                string NamaSupplier = txtNama.Text;
                string Alamat = txtAlamat.Text;
                string Email = txtEmail.Text;
                string Kontak = txtKontak.Text;

                // Validasi data sebelum diupdate
                if (string.IsNullOrWhiteSpace(NamaSupplier) || string.IsNullOrWhiteSpace(Alamat) || string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(Kontak))
                {
                    MessageBox.Show("Semua data harus diisi!", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Melakukan update ke database
                using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
                {
                    try
                    {
                        // Query untuk memperbarui data supplier
                        string query = @"UPDATE tabel_supplier 
                                 SET nama_supplier = @nama_supplier, 
                                     alamat = @alamat, 
                                     email = @email, 
                                     kontak = @kontak 
                                 WHERE id_Supplier = @id_Supplier";

                        // Membuat MySqlCommand untuk menjalankan query
                        using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                        {
                            // Menambahkan parameter
                            cmd.Parameters.AddWithValue("@id_Supplier", idSupplier);
                            cmd.Parameters.AddWithValue("@nama_supplier", NamaSupplier);
                            cmd.Parameters.AddWithValue("@alamat", Alamat);
                            cmd.Parameters.AddWithValue("@email", Email);
                            cmd.Parameters.AddWithValue("@kontak", Kontak);

                            // Menjalankan perintah update
                            int rowsAffected = cmd.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Data berhasil diperbarui!");
                                TampilkanData(); // Perbarui ListView untuk menampilkan data terbaru
                            }
                            else
                            {
                                MessageBox.Show("Data gagal diperbarui.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Pilih data supplier yang ingin diupdate terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
