﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;
using FP_PEMRO_KEL_3.Controller;



namespace FP_PEMRO_KEL_3
{
    public partial class GudangBarang : Form
    {
        public static GudangBarang instance;
        public GudangBarang()
        {
            InitializeComponent();
            instance = this;
         
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string sandi = txtPassword.Text;

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Query untuk memeriksa username dan password
                    string query = "SELECT * FROM tabel_user WHERE username = @Username AND Sandi = @Sandi";

                    // Membuat MySqlCommand dengan koneksi dari DbContext
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        cmd.Parameters.AddWithValue("@Username", username);
                        cmd.Parameters.AddWithValue("@Sandi", sandi);

                        // Membaca data dari database
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                MessageBox.Show("Login Berhasil!");
                                // Lakukan tindakan setelah login berhasil
                                Hello_World form = new Hello_World();
                                form.Show();
                            }
                            else
                            {
                                MessageBox.Show("Username atau Password salah!");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnBuatAkun_Click(object sender, EventArgs e)
        {
            FrmUser form = new FrmUser();
            form.Show();
        }
    }
}