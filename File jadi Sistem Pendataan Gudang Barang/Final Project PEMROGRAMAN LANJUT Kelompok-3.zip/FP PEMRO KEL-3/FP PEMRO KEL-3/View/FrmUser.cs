﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using FP_PEMRO_KEL_3.Model.Entity;
using FP_PEMRO_KEL_3.Model.Repository;
using FP_PEMRO_KEL_3.Model.Context;
using FP_PEMRO_KEL_3.Controller;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;


namespace FP_PEMRO_KEL_3
{
    public partial class FrmUser : Form
    {
        public static FrmUser instance;
        public FrmUser()
        {
            InitializeComponent();
            instance=this;
        }
        private void ResetForm()
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtNama.Clear();
            
        }
        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string Username = txtUsername.Text;
            string Sandi = txtPassword.Text;
            string Role = cmbRole.Text;
            string nama = txtNama.Text;

            using (var context = new FP_PEMRO_KEL_3.Model.Context.DbContext())
            {
                try
                {
                    // Query untuk menyimpan data ke tabel_user
                    string query = @"INSERT INTO tabel_user (nama_pengguna, Username, Sandi, Role) 
                             VALUES (@nama_pengguna, @Username, @Sandi, @Role)";

                    // Membuat MySqlCommand dengan koneksi dari DbContext
                    using (MySqlCommand cmd = new MySqlCommand(query, context.Conn))
                    {
                        // Menambahkan parameter
                        cmd.Parameters.AddWithValue("@nama_pengguna", nama);
                        cmd.Parameters.AddWithValue("@Username", Username);
                        cmd.Parameters.AddWithValue("@Sandi", Sandi);
                        cmd.Parameters.AddWithValue("@Role", Role);

                        // Menjalankan query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Data berhasil disimpan!");
                        }
                        else
                        {
                            MessageBox.Show("Data gagal disimpan.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetForm();
        }
    }
}
